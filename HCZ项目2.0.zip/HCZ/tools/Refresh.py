from video.models import VideoProfile
from django.core.cache import caches

class VideoModle:
    def __init__(self,name,v_id,like):
        self.name=name
        self.id=v_id
        self.like=like

    def __eq__(self,obj):
        return self.name==obj.name

    def __str__(self):
        return f'视频名：{self.name}，点赞数量：{self.like}'

class RefreshManage:
    count = 0
    l_redis = caches['NumLists']
    # (视屏名,视屏id,收藏数)
    lists = list()

    @classmethod
    def refresh_lists(cls):
        print('开始读取排行榜')
        videos = VideoProfile.objects.all()

        # v.name视屏名 len(users)收藏数量

        for v in videos:
            users = v.like.all()
            video=VideoModle(v.name,v.id,len(users))
            # print(video)

            cls.install(video)

        target=[]
        for v in cls.lists:
            target+=[(v.name,v.id,v.like)]
        print('存入的redis为'.format(target))
        cls.l_redis.set('Numlists', target, 30)

        print('排行榜读取结束')

    @classmethod
    def install(cls, video:VideoModle):
        if not cls.lists:
            cls.lists.append(video)
        else:
            # 循环目标
            for i in range(len(cls.lists)):
                # 如果目标
                if cls.lists[i].like < video.like and not video in cls.lists:
                    # (视屏名,视屏id,收藏数)
                    cls.lists.insert(i, video)
                    break
            else:
                cls.lists.insert(-1, video)

            while len(cls.lists) > 10:
                cls.lists.pop(-1)
