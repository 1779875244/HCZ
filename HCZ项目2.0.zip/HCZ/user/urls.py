from django.urls import path, include
from . import views

urlpatterns = [
    # 127.0.0.1:8000/v1/users/sms
    path('/sms', views.sms_view),
    path('/portrait',views.Portrait.as_view()),
    # 127.0.0.1:8000post_user_xgmm/v1/users/tedu
    path('/get_user_server',views.get_user_server),
    path('/judge_name',views.judge_name),
    path('/post_user_xgmm',views.post_user_xgmm),
    # path('/video',include('video.uls')),
    path('/modify_personal_information',views.modify_personal_information),
    path('/<str:username>/password', views.UsersView.as_view()),
    path('/<str:username>/avatar', views.user_avatar),
]
