import os

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.views import View

import json

from tools import logging_dec
from .models import UserProfile
# from hashlib import md5
import hashlib
from btoken.views import make_token
from django.conf import settings
import time
import jwt
from tools.logging_dec import logging_check
from django.utils.decorators import method_decorator
from django.core.cache import cache
import random
from tools.sms import YunTongXin
from django.conf import settings

from .tasks import send_sms
from user.models import UserProfile


# Create your views here.

# user的code: 10100~10199
class UsersView(View):
    def get(self, request, username=None):
        if username:
            try:
                user = UserProfile.objects.get(username=username)
            except Exception as e:
                print("get user error %s" % e)
                result = {'code': 10104, 'error': 'username is wrong'}
                return JsonResponse(result)
            # 根据查询字符串的键获取指定的数据
            if request.GET.keys():
                data = {}
                for k in request.GET.keys():
                    if k == 'password':
                        continue
                    if hasattr(user, k):
                        data[k] = getattr(user, k)
                result = {'code': 200, 'username': username, 'data': data}
                return JsonResponse(result)
            else:

                result = {'code': 200, 'username': username,
                          'data': {'info': user.info, 'sign': user.sign,
                                   'nickname': user.nickname, 'avatar': str(user.avatar)}}
                return JsonResponse(result)
        else:
            return HttpResponse('-all users-')

    def post(self, request):
        json_str = request.body
        json_obj = json.loads(json_str)
        username = json_obj['username']
        email = json_obj['email']
        phone = json_obj['phone']
        password_1 = json_obj['password_1']
        password_2 = json_obj['password_2']
        sms_num = json_obj['sms_num']
        # 校验验证码
        cache_key = 'sms_%s' % (phone)
        print('验证码1:',cache_key)
        old_code = cache.get(cache_key)
        # 验证码过期
        if not old_code:
            result = {'code': 10113, 'error': 'code is wrong'}
            return JsonResponse(result)
        # 比较
        if int(sms_num) != old_code:
            result = {'code': 10114, 'error': 'code is wrong2'}
            return JsonResponse(result)

        if len(username) > 11:
            result = {'code': 10100, 'error': 'username is too long'}
            return JsonResponse(result)
        # 用户名是否可用
        old_user = UserProfile.objects.filter(username=username)
        if old_user:
            result = {'code': 10101, 'error': 'username is exist'}
            return JsonResponse(result)
        # 处理密码
        if password_1 != password_2:
            result = {'code': 10102, 'error': 'password is error'}
            return JsonResponse(result)
        md5 = hashlib.md5()
        md5.update(password_1.encode())
        password_m = md5.hexdigest()
        # 插入数据
        try:
            user = UserProfile.objects.create(username=username,
                                              password=password_m, email=email,
                                              phone=phone)
        except Exception as e:
            print('create error is %s' % e)
            result = {'code': 10101, 'error': 'username is exist'}
            return JsonResponse(result)

        # 签发jwt
        token = make_token(username)
        return JsonResponse({'code': 200, 'username': username, 'data': {'token': token.decode()}})

    @method_decorator(logging_check)
    def put(self, request):
        # 不使用第三个参数了，user从装饰器中给request增加的附加属性myuser获取
        json_str = request.body
        json_obj = json.loads(json_str)
        # old_password: "123"
        # password_1: "123"
        # password_2: "123"
        # username: "test_user"
        old_password = json_obj["old_password"]
        password_1 = json_obj["password_1"]
        password_2 = json_obj["password_2"]
        username = json_obj["username"]

        if password_1 != password_2:
            result = {'code': 10086, 'error': '密码不一致，请重新输入'}
            return JsonResponse(result)
        else:
            try:
                user_mod = UserProfile.objects.get(username=username)
                box = hashlib.md5()
                box.update(old_password.encode())
                old_psd = box.hexdigest()
                if user_mod.password != old_psd:
                    result = {'code': 10086, 'error': '原始密码错误，请重新输入'}
                    return JsonResponse(result)
                else:
                    box2 = hashlib.md5()
                    box2.update(password_1.encode())
                    new_psd = box2.hexdigest()
                    user_mod.password = new_psd
                    user_mod.save()
                    result = {'code': 200, 'data': '修改成功'}
                    return JsonResponse(result)


            except:
                result = {'code': 10086, 'error': '用户不存在，请重新登录'}
                return JsonResponse(result)

        result = {'code': 200, 'username': request.myuser.username}
        return JsonResponse(result)


@logging_check
def user_avatar(request, username):
    if request.method != 'POST':
        result = {'code': 10105, 'error': 'please give me POST'}
        return JsonResponse(result)
    # 1.从url中获取username
    # user = UserProfile.objects.get(username=username)

    # 2.从装饰器中由request的附加属性myuser获取user
    user = request.myuser
    user.avatar = request.FILES['avatar']
    user.save()
    # result = {'code':200,'username':username}
    result = {'code': 200, 'username': user.username}
    return JsonResponse(result)


def sms_view(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    phone = json_obj['phone']
    print(phone)
    # 防止用户多次点击按钮重复发送验证码
    cache_key = 'sms_%s' % (phone)
    old_code = cache.get(cache_key)
    if old_code:
        result = {'code': 10112, 'error': '请稍后再来'}
        return JsonResponse(result)
    # 生成随机码
    code = 123456
    print(code)
    # 放到缓存中,有效期65秒
    print('验证码2:',cache_key)
    cache.set(cache_key, 123456, 65)

    # 同步发送
    # x = YunTongXin(settings.SMS_ACCOUNT_ID, settings.SMS_ACCOUNT_TOKEN,
    #                settings.SMS_APP_ID, settings.SMS_TEMPLATE_ID)
    # res = x.run('18180460882', code)
    # print(res)

    # 异步发送
    # send_sms.delay(phone, code)

    return JsonResponse({'code': 200})


@logging_check
def get_user_server(request):
    user = request.myuser
    user_list = []
    dic = {}
    dic['username'] = user.username
    dic['email'] = user.email
    dic['phone'] = user.phone
    dic['sex'] = user.sex
    dic['vip'] = user.vip
    user_list.append(dic)
    return JsonResponse(user_list, safe=False)
    # return JsonResponse({'code': 10000, 'error': 'tset'})


@logging_check
def post_user_xgmm(request):
    print('-----------------------')
    print(request.myuser)
    print(request.myuser)
    yuanshimima = request.POST['yuanshimima']
    password = request.POST['password']
    UserProfile.objects.get('username')

    return JsonResponse({'code': 10000, 'error': 'tset'})


# 修改个人信息
@logging_check
def modify_personal_information(request):
    GENDER_CHOICES = {
    '男':0,
    '女':1,
    '外星人':2,
    }

    user = request.myuser
    json_str = request.body
    json_obj = json.loads(json_str)
    username = json_obj['passname']
    email = json_obj['email']
    phone = json_obj['phone']
    sex = json_obj['sex']

    try:
        user.username = username
        user.email = email
        user.phone = phone
        user.sex = GENDER_CHOICES[sex]
        token = make_token(username)
        user.save()
        return JsonResponse({'code': 200, 'username': username, 'data': {'token': token.decode()}})
    except Exception as e:
        print(e)
        result = {'code': 63030, 'error': '改造失败'}
        return JsonResponse(result)


# 异步提交验证用户名是否存在
def judge_name(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    username = json_obj['username']
    try:
        user_mod = UserProfile.objects.get(username=username)
        result = {"code": 10001, 'error': '用户名已经存在'}
        return JsonResponse(result)
    except:
        result = {'code': 200, 'error': '用户名可以使用'}
        return JsonResponse(result)

class Portrait(View):
    def dispatch(self, request, *args, **kwargs):
        # 获取请求头中的token
        token = request.META.get('HTTP_AUTHORIZATION')
        if not token:
            result = {'code': 403, 'error': 'please login'}
            return JsonResponse(result)
        # 校验token
        try:
            res = jwt.decode(token, settings.JWT_TOKEN_KEY, algorithm='HS256')
        except Exception as e:
            print('token错误')
            result = {'code': 403, 'error': 'please login'}
            return JsonResponse(result)
        username = res['username']
        user = UserProfile.objects.get(username=username)
        request.myuser = user

        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        '''
        获取头像
        '''
        try:
            url = request.myuser.touxiang

            return JsonResponse({'code': 200, 'url': url})
        except:
            return JsonResponse({'code': 10086, 'error': '头像错误'})

    def post(self, request):
        '''
        添加头像
        '''
        try:
            user=request.myuser

            #静态文件位置
            path = 'client/static/'
            #头像存储位置
            imgs = 'images/touxiang/'
            #文件对象
            touxiang = request.FILES['portrait']
            #拼接文件名:-->用户名+文件上传名
            name = user.username+touxiang.name

            #项目路径
            save_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            #整合路径
            save_path_over = os.path.join(save_path, path+imgs)

            # print("上传文件名是:", name)
            # print('保存的位置是:{}'.format(save_path))


            #判断是否为默认头像
            try:
                if user.touxiang != 'images/touxiang/default.png':
                    os.remove(save_path+'/'+path+user.touxiang)
            except:
                pass

            print('--------------',imgs + name)

            user.touxiang = imgs + name
            user.save()

            # 保存文件
            with open(save_path_over + name, 'wb') as f:
                # 获取文件流
                f.write(touxiang.file.read())

            return JsonResponse({'code': 200, 'data': '上传成功'})

        except:
            user = request.myuser
            user.touxiang = 'images/touxiang/default.png'
            user.save()
            return JsonResponse({'code': 10086, 'data': '上传失败'})
