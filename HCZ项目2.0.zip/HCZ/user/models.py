from django.db import models


# Create your models here.
class UserProfile(models.Model):
    GENDER_CHOICES = (
        (0, '男'),
        (1, '女'),
        (2, '外星人')
    )
    username = models.CharField('用户名', max_length=50)
    password = models.CharField('密码', max_length=50)
    email = models.EmailField('邮箱')
    sex = models.SmallIntegerField('性别', choices=GENDER_CHOICES, default=2)
    phone = models.CharField('电话', max_length=11, default='')
    touxiang = models.CharField('头像', max_length=500, default='images/touxiang/default.png')
    vip = models.BooleanField(default=False)
    vip_start_time = models.DateTimeField(auto_now_add=True)
    vip_end_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'用户名：{self.username}'

    class Meta:
        # 定义表名
        db_table = "user"


class Category01(models.Model):
    name = models.CharField('大分类', max_length=10)

    class Meta:
        # 定义表名
        db_table = "category01"


class Category02(models.Model):
    name = models.CharField('小分类', max_length=20)

    class Meta:
        # 定义表名
        db_table = "category02"


class Associate(models.Model):
    jieshao = models.CharField('内容类型', max_length=50)
    category01 = models.ForeignKey(Category01, on_delete=models.CASCADE)
    category02 = models.ForeignKey(Category02, on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "associate"


class AV(models.Model):
    jieshao = models.CharField('内容类型', max_length=50)
    associate = models.ForeignKey(Associate, on_delete=models.CASCADE)
    video = models.ForeignKey('video.VideoProfile', on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "av"
