import pika

# 创建连接对象
connection = pika.BlockingConnection(pika.ConnectionParameters(
    host='127.0.0.1'))

# 创建管道
channel = connection.channel()

# 创建交换机
channel.exchange_declare(exchange='news_info',
                         exchange_type='direct')			# 设置关键字模式

# 创建消息队列
q = channel.queue_declare("", exclusive=True)
# 获取队列名
queue_name = q.method.queue

k = 'room1'
# 绑定队列到交换机
channel.queue_bind(exchange='news_info',
                   queue=queue_name,
                   routing_key=k)


def huidao(ch, method, properties, body):
    '''
    消息处理回调函数
    '''
    print('收到消息', body.decode())
    # channel.stop_consuming()


print('开始消费')
# 配置消费者
channel.basic_consume(queue=queue_name,
                      auto_ack=True,
                      on_message_callback=huidao)

# 开启消费者
channel.start_consuming()
print('结束消费')
