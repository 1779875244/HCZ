import uvloop
import asyncio
from threading import Thread
import aioredis
import pika



async def consumer(c):
    r = await aioredis.create_redis('redis://tarena:@127.0.0.1:6379/6')
    while 1:
        result = await r.brpop('chat_room_info')
        # 获取消息
        # 53384@##@room1@##@hello
        result = result[1].decode()
        (port, num, info) = result.split('@##@', 2)

        room_obj = c.room_list[num]
        name = room_obj.user_online[port].name
        for u_port, user in room_obj.user_online.items():
            try:
                if port != u_port:
                    await user.send({'type': 'websocket.send', 'text': name+': '+info})
            except:
                pass

    r.close()


def run_consumer(room_c):
    # 设置uvloop协程池
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    # 创建协程池
    loop = asyncio.get_event_loop()

    # 创建4个消费者任务
    tasks = [asyncio.ensure_future(consumer(room_c)) for _ in range(4)]

    print('开启消费者线程')
    # 创建线程
    t = Thread(target=loop.run_until_complete, args=(asyncio.wait(tasks),))
    # 设置主线程退出子线程
    t.setDaemon(True)

    # 开始线程
    t.start()


class Model_User:
    '''
    用户模型
    '''

    def __init__(self, name='', prot='', room='', send=None):
        self.name = name
        self.prot = prot
        self.send = send
        self.room = room

    def __str__(self):
        return f'用户:{self.name}--端口号:{self.prot}--所属聊天室:{self.room}'

    def __eq__(self, obj):
        return self.prot == obj.prot


class Chat_room:
    '''
    聊天室模型
    '''

    def __init__(self, num=''):
        self.num = num
        self.user_online = {}

    def __str__(self):
        return f'聊天室编号{self.num}'

    def add(self, user: Model_User):
        try:
            self.user_online[user.prot] = user
            return True
        except:
            return False

    def remove(self, user):
        try:
            del self.user_online[user.prot]
            return True
        except:
            return False


class RqTool:
    '''
    rabbitmq工具
    '''
    # @staticmethod
    # def send(key: str, text: str):
    #     text='用户--'+text
    #     print('消息:{},key:{}'.format(text,key))

    @staticmethod
    def send(key: str, text: str):
        # 创建连接对象
        connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='127.0.0.1'))
        # 创建管道
        channel = connection.channel()

        # 创建交换机
        channel.exchange_declare(exchange='news_info',exchange_type='direct')

        text='用户--'+text

        channel.basic_publish(exchange='news_info',routing_key=key,body=text)

        connection.close()
