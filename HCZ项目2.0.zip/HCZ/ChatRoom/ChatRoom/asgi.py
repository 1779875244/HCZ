"""
ASGI config for ChatRoom project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.1/howto/deployment/asgi/
"""

import os

from django.core.asgi import get_asgi_application
from ChatRoom import control as c

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ChatRoom.settings')

http_application = get_asgi_application()

# 异步处理请求
async def application(scope, receive, send):
    # 打印链接信息
    # print('打印信息: scope ---',scope)control
    # print('打印信息: receive ---',receive)
    # print('打印信息: send ---',send)
    # print('打印信息: scope ---',type(scope))
    # print('打印信息: receive ---',type(receive))
    # print('打印信息: send ---',type(send))
    # 判断链接请求类型
    if scope['type'] == 'http':
        print('收到了HTTP请求')
        # http请求处理应用
        await http_application(scope, receive, send)
    elif scope['type'] == 'websocket':
        print('收到了websocket请求')
        # websocket请求处理应用
        await c.websocket_application(scope, receive, send)
    else:
        raise Exception('未知请求协议:', scope['type'])