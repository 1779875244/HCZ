"""
聊天室控制
=============
此模块完成接收处理websocket的请求,
并调度redis消费者线程
"""

import re

from ChatRoom.toolbox import Model_User, run_consumer, Chat_room, run_consumer, RqTool
import datetime
import aioredis
import sys
import os

root_path = os.path.dirname(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)
sys.path.append(root_path)


class Control_room:  # 用户控制
    # {聊天室名称:聊天室对象,...}
    room_list = dict()  # 聊天室列表字典

    def del_user(self, user):
        '''
        从用户在线字典删除用户
        '''
        self.room_list[user.room].remove(user)
        # 向mq发送用户离开信息
        msg='{}离开了聊天室'.format(user.name)
        RqTool.send(user.room,msg)

    def _add_user(self, user: Model_User, room: str):
        '''
        向聊天室列表字典添加用户
        '''
        # 判断聊天室是否存在
        if room in self.room_list:
            # 向这个聊天对象添加用户对象
            self.room_list[room].add(user)
        else:
            chatroom = Chat_room(room)
            chatroom.add(user)
            self.room_list[room] = chatroom
        # 发送消息用户进入通知
        msg='{}进入了聊天室'.format(user.name)
        RqTool.send(user.room,msg)

    async def accept(self, send, port):
        '''
        ws协议建立握手
        '''
        user = Model_User(prot=port, send=send)
        await send({'type': 'websocket.accept'})
        return user

    async def info_handle(self, text: str, user: Model_User, r):
        '''
        消息处理函数
        '''
        data = text.split('@##@', 1)
        # login@##@name@##@room
        if data[0] == 'login':
            (name, num) = data[1].split('@##@', 1)
            user.name = name
            print('用户：', name)
            try:
                num = re.findall(r'http://127.0.0.1:5000/video/(sp\d+)/\d*', num)[0]
                print('聊天室：',num)
            except:
                raise Exception('非法请求格式')
            user.room = num
            # 将用户注册到聊天室
            self._add_user(user, num)
            print('用户:{}注册到聊天室:{}'.format(name, num))

        # info@##@XXXXXXXXXXXXXXXXXXXXX
        elif data[0] == 'info':
            if data[1] == '时间':
                text = datetime.datetime.now().strftime('%Y年%m月%d日\n%H:%M:%S')
                await user.send({'type': 'websocket.send', 'text': text})

            else:

                await r.lpush('chat_room_info', user.prot + '@##@' + user.room + '@##@' + data[1])

        else:
            await user.send({'type': 'websocket.send', 'text': 'ERROR'})


async def websocket_application(scope, receive, send):
    '''
        websocket链接处理函数
    '''
    global c
    user = None
    r = await aioredis.create_redis('redis://tarena:@127.0.0.1:6379/6')

    while 1:
        event = await receive()

        # 若请求格式为消息请求
        if event['type'] == 'websocket.receive':
            try:
                await c.info_handle(event['text'], user, r)
            except Exception as e:
                print('断开非法请求', scope["client"][1])

        # 若请求格式为连接请求
        elif event['type'] == 'websocket.connect':
            # 返回握手信息
            print(f'收到{scope["client"][1]}连接,建立握手')
            user = await c.accept(send, str(scope["client"][1]))

        # 若请求格式为断开请求
        elif event['type'] == 'websocket.disconnect':
            # 退出循环
            break
        else:
            print('未知请求格式：', event['type'])

        for num, room in c.room_list.items():
            print('聊天室{num}：', room.user_online)

    print(f'{scope["client"][1]}断开连接')
    r.close()
    # 网络IO操作：关闭redis连接
    await r.wait_closed()
    # 将用户从聊天室出列
    c.del_user(user)


c = Control_room()
run_consumer(c)
