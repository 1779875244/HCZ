from django.db import models
from user.models import UserProfile


# Create your models here.
class History(models.Model):
    end_time = models.DateTimeField(auto_now=True)
    video = models.ForeignKey('video.VideoProfile', on_delete=models.CASCADE)
    userProfile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "history"


class Topic(models.Model):
    title = models.CharField('文章标题', max_length=50)
    introduce = models.CharField('文章简介', max_length=30)
    content = models.TextField('文章内容')
    create_time = models.DateTimeField(auto_now_add=True)
    update_time = models.DateTimeField(auto_now=True)
    userProfile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "topic"


class Message(models.Model):
    # 留言/回复
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    userProfile = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    content = models.CharField('留言内容', max_length=50)
    create_time = models.DateTimeField(auto_now_add=True)
    parent_message = models.IntegerField('回复的留言的ID', default=0)

    class Meta:
        # 定义表名
        db_table = "message"
