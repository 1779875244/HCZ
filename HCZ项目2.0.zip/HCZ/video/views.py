from django.core import serializers
from django.http import JsonResponse
from django.conf import settings
from django.views import View
from .models import VideoProfile,Video
from user.models import UserProfile
from user.models import Category01, Category02
import json
import jwt
import re
from tools.Refresh import RefreshManage
import time

# Create your views here.
# code : 10200-10299
class VideoView(View):
    def get(self, request, name):
        pass

    def post(self, request):
        json_str = request.body
        json_obj = json.loads(json_str)
        name = json_obj['name']
        id = json_obj['cid']
        print('****************************')
        print(name)
        print(id)
        try:
            # 小分类
            category = Category02.objects.get(name=name)
            print('-------------',id,category.id)
            videos = VideoProfile.objects.raw('select * from video left join av on av.video_id = video.id left join associate as a on a.id = av.associate_id where a.category01_id = {} and a.category02_id = {}'.format(id,category.id))
            vids = VideoProfile.objects.raw('select video.id from video left join av on av.video_id = video.id left join associate as a on a.id = av.associate_id where a.category01_id = {} and a.category02_id = {}'.format(id,category.id))
        except Exception as e:
            data = {'code': 10200}
            return JsonResponse(data)
        videos_res = make_videos_res(videos)
        ids = make_vids(vids)
        print(ids)
        data = {'code': 200, 'videos': videos_res, 'ids': ids}
        return JsonResponse(data)


def make_videos_res(videos):
    videos_res = []
    ids = []
    for video in videos:
        d = {}
        d['id'] = video.id
        d['name'] = video.name
        d['href'] = video.href
        d['jianjie'] = video.jianjie
        d['count'] = video.count
        videos_res.append(d)
    return videos_res


def make_videos(videos):
    videos_res = []
    ids = []
    for video in videos:
        d = {}
        d['id'] = video.id
        d['name'] = video.name
        d['href'] = video.href
        d['count'] = video.count
        videos_res.append(d)
    return videos_res


def make_vids(vids):
    ids = []
    for vid in vids:
        d = {}
        d['id'] = vid.id
        ids.append(d)
    return ids


def get_video(request, id):
    json_str = request.body
    json_obj = json.loads(json_str)
    name = json_obj['name']
    print(name)
    videoProfile = VideoProfile.objects.get(id=id)
    print(videoProfile.id)
    video = Video.objects.filter(videoProfile_id = videoProfile.id)[0]
    regex = "src='(.*?)'"
    pattern = re.compile(regex,re.S)
    href = pattern.findall(video.href)
    d = {}
    d['id'] = video.id
    d['name'] = video.name
    d['href'] = href
    d['count'] = video.count
    d['img'] = videoProfile.href
    d['jianjie']=videoProfile.jianjie
    print('*' * 50)
    print(d)
    data = {'code':200,'video':d}
    return JsonResponse(data)

def get_videos(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    vid = json_obj['vid']
    print('****************************')
    print(vid)
    try:
        videos = Video.objects.filter(videoProfile_id=vid)
    except Exception as e:
        data = {'code': 10300}
        return JsonResponse(data)
    videos_res = make_videos(videos)
    data = {'code': 200, 'videos': videos_res}
    return JsonResponse(data)

def get_url_text(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    vid = json_obj['vid']
    try:
        video = Video.objects.get(id=vid)
    except Exception as e:
        data = {'code': 10300}
        return JsonResponse(data)
    regex = "src='(.*?)'"
    pattern = re.compile(regex, re.S)
    href = pattern.findall(video.href)
    d = {}
    d['id'] = video.id
    d['name'] = video.name
    d['href'] = href
    d['count'] = video.count
    print('*' * 50)
    data = {'code': 200, 'video': d}
    return JsonResponse(data)


def get_id(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    name = json_obj['name']
    try:
        category = Category02.objects.get(name=name)
    except Exception as e:
        data = {'code': 10400}
        return JsonResponse(data)

    data = {'code': 200, 'id': category.id}
    return JsonResponse(data)

class Likes(View):
    def dispatch(self, request, *args, **kwargs):
        # 获取请求头中的token
        token = request.META.get('HTTP_AUTHORIZATION')
        if not token:
            result = {'code': 403, 'error': 'please login'}
            return JsonResponse(result)
        # 校验token
        try:
            res = jwt.decode(token, settings.JWT_TOKEN_KEY, algorithm='HS256')
        except Exception as e:
            print('token错误')
            result = {'code': 403, 'error': 'please login'}
            return JsonResponse(result)
        username = res['username']
        user = UserProfile.objects.get(username=username)
        request.myuser = user

        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        '''
        获取点赞
        '''
        user=request.myuser

        sp_rul = request.META.get('HTTP_REFERER', '')
        # http://127.0.0.1:5000/hcz/video/sp1/6
        #http://127.0.0.1:5000/video/sp2/0
        # http://127.0.0.1:5000/hang

        html_url = re.findall(r'http://127.0.0.1:5000/(\S+)', sp_rul)

        if html_url is None:
            return JsonResponse({'code': 10086, 'error': '错误'})
        # 如果是个人信息页则返回该用户所有收藏
        elif html_url[0] == 'hang':
            videos=user.videoprofile_set.all()
            list_sp=list()
            for v in videos:
                list_sp+=[(v.id,v.name)]
            print(list_sp)
            return JsonResponse({'code': 200, 'data': list_sp})

        # 如果是视屏页则返回用户是否收藏
        else:
            #取出视屏ID
            sp_id = re.findall(r'http://127.0.0.1:5000/video/sp(\d+)/\d*', sp_rul)
            if sp_id == []:
                return JsonResponse({'code': 10086, 'error': '错误'})
            try:
                v=user.videoprofile_set.get(id=sp_id[0])
                return JsonResponse({'code': 200, 'data': 'YES'})
            except Exception as e:
                print('错误',e)
                return JsonResponse({'code': 200, 'data': 'NO'})


    def post(self, request):
        '''
        提交点赞
        '''
        # 获取用户
        user = request.myuser

        # sp=1&js=2
        sp_url=request.META.get('HTTP_REFERER','')
        # sp_url = request.body
        # sp_url = json.loads(sp_url)

        if not sp_url:
            return JsonResponse({'code': 10086, 'error': '错误'})
        # {'sp_url': 'http://127.0.0.1:5000/hcz/video/sp1/6'}
        #http://127.0.0.1:5000/video/sp2/0

        # 获取视频ID
        sp_id = re.findall(r'http://127.0.0.1:5000/video/sp(\d+)/\d*', sp_url)
        if sp_id == []:
            return JsonResponse({'code': 10086, 'error': '错误'})

        try:
            video = VideoProfile.objects.get(id=sp_id[0])
            video.like.add(user)

            return JsonResponse({'code': 200, 'data': '成功'})
        except Exception as e:
            print('错误', e)
            return JsonResponse({'code': 10086, 'error': '错误'})

class Lists(View):
    def get(self, request):
        '''
        获取排行榜
        '''

        data = RefreshManage.l_redis.get('Numlists')
        while not data:
            if RefreshManage.count == 0:
                RefreshManage.count = 1
                RefreshManage.refresh_lists()
                RefreshManage.count = 0
            time.sleep(0.5)
            data = RefreshManage.l_redis.get('Numlists')

        print('data为',data)
        return JsonResponse({'code': 200, 'data': data})

class Sousuo(View):
    def get(self,request):
        text=request.GET.get('target','')
        if not text:
            return JsonResponse({'code': 10086, 'error': '暂无此视频'})

        try:
            v=VideoProfile.objects.get(name=text)
            id=v.id
            return JsonResponse({'code': 200, 'data': id})
            # return JsonResponse({'code': 10086, 'error': '暂无此视频'})
        except:
            return JsonResponse({'code': 10086, 'error': '暂无此视频'})

