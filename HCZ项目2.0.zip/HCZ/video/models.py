from django.db import models


# Create your models here.
from user.models import UserProfile


class VideoProfile(models.Model):
    name = models.CharField('视频名称', max_length=50)
    href = models.CharField('视频链接', max_length=255)
    jianjie = models.CharField('视频简介', max_length=255)
    count = models.IntegerField('点赞数量')
    category01 = models.ForeignKey('user.Category01', on_delete=models.CASCADE)
    like = models.ManyToManyField(UserProfile)

    class Meta:
        # 定义表名
        db_table = "video"


class Video(models.Model):
    name = models.CharField('视频名称', max_length=50)
    href = models.CharField('视频链接', max_length=255)
    count = models.IntegerField('点赞数量')
    videoProfile = models.ForeignKey(VideoProfile, on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "video1"

class Comment(models.Model):
    text = models.CharField('评论内容', max_length=255)
    userProfile = models.ForeignKey('user.UserProfile', on_delete=models.CASCADE)
    video = models.ForeignKey(VideoProfile, on_delete=models.CASCADE)

    class Meta:
        # 定义表名
        db_table = "comment"
