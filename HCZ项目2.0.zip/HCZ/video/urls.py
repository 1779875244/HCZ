from django.urls import path
from . import views

urlpatterns = [
    # path('<str:name>', views.VideoView.as_view())
    path('sousuo',views.Sousuo.as_view()),
    path('lists',views.Lists.as_view()),
    path('like', views.Likes.as_view()),
    path('<int:id>', views.get_video),
    path('shiping', views.get_videos),
    path('get_url_text', views.get_url_text),
    path('get_id', views.get_id),

]
