import pika
import time
from random import choice

msg =[
    '不枉此生扮剑侠！','剑随心走，大天使之剑等你来！',
    '战斗终结者，我是大赢家！',
    '我就是力量的化身，所向披靡，唯我独尊。',
    '大天使之剑，尊爱神之心！',
    '神梦之心，尽在大天使之剑！',
    '勇闯魔境，剑指天下。',
    '新服大放送，享赚你就来！',
    '魔域之王，战神之剑。',
    '群雄之争，谁与争锋，倾城所予。',
    '大天使！玩的真爽！',
    '攻城争夺战，团结共奋斗！',
    '大天使之剑，老魔鬼之魂！',
    '好游戏，共赏玩。',
    '精彩，只等你来！',
    '大天使之剑，真上帝之刀！',
    '缤纷秀坐骑，耍酷炫体验！',
    '大天使之剑，乘胜追击、一往无前！',
    '让战斗更浓烈，让命运更壮烈。',
    '神美剑颠，尽在大天使之剑！',
    '纵橫天下，唯我独尊！',
    '精英挑战日，勇往争第一！',
    '大天使之剑，游戏战舰！',
    '网游剑颠，尽在大天使之剑！',
    '充值排行榜，看谁真土豪！',
    '十年一剑，沉浮云间，英雄诗篇。',
    '大天使之剑，做最强剑侠！',
    '冲级排行赛，挑战乐不停！',
    '挥舞吧，战斗吧，英雄！',
    '西方魔幻游戏，激情尽显、大天使之剑！',
    '大天使之剑，聚焦正能量！',
    '指间下的热血，等待创造奇迹的强者！',
]

# 创建连接对象
connection = pika.BlockingConnection(pika.ConnectionParameters(
    host='127.0.0.1'))

# 创建管道
channel = connection.channel()

# 创建交换机
channel.exchange_declare(exchange='news_info',
                         exchange_type='direct')			# 设置关键字模式

def run(msg: list,second: int):
    # 获取消息长度
    print('开始发送广告')
    while 1:
        # 随机获取消息
        message = '广告--'+choice(msg)

        # print(message)
        channel.basic_publish(exchange='news_info',
                              routing_key='system',		# 设置发送关键字
                              body=message)

        time.sleep(second)

if __name__ == "__main__":
    print('请输入广告发送间隔(单位:秒)')
    try:
        s=int(input('>>'))
        run(msg,s)
    except ValueError:
        print('请输入正确的时间')