'''
rabbitmq交换机管理模块
'''

import pika
import time
from threading import Thread

# # 创建连接对象
# connection = pika.BlockingConnection(pika.ConnectionParameters(
#     host='127.0.0.1',heartbeat=0))

# # 创建管道
# channel = connection.channel()

# 创建交换机
# channel.exchange_declare(exchange='news_info',exchange_type='direct')			# 设置关键字模式


class Queue:
    def __init__(self, name: str = '', keys: list = []):
        # 交换机对应用户名
        self.name = name
        # 创建交换机后300秒内没使用则过期
        self.time = time.time()+300
        # 绑定关键字列表
        self.key = keys
        # 结果存储容器
        self.info = None

        # 创建连接对象
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(
            host='127.0.0.1', heartbeat=0))

        self.channel = self.connection.channel()

        # 创建交换机
        self.channel.exchange_declare(exchange='news_info',exchange_type='direct')

        # 创建消息队列
        self.q = self.channel.queue_declare("", exclusive=True)
        # 获取队列名
        self.queue_name = self.q.method.queue

        for k in self.key:
            # 绑定队列到交换机
            self.channel.queue_bind(exchange='news_info',
                                    queue=self.queue_name,
                                    routing_key=k)

    def __str__(self):
        return f'队列名{self.name}'

    def __get_info(self, ch, method, properties, body):
        '''
        消息处理回调函数
        '''
        self.info = body.decode()
        # print('收到消息', body.decode())
        self.channel.stop_consuming()
        return True

    async def run(self):
        print('开始消费')
        # 配置消费者
        self.channel.basic_consume(queue=self.queue_name,
                                auto_ack=True,
                                on_message_callback=self.__get_info)


        #刷新交换机时间
        self.time=9999999999999999999.9
  
        # 开启消费者
        self.channel.start_consuming()

        #更新交换机时间
        self.time=time.time()+180
        print('结束消费')


class ExchangeManage:
    '''
        交换机管理工具
    '''
    # 交换机名称：交换机
    queues = dict()

    # 新增交换机
    @classmethod
    async def add(cls, user: str = '', keys: list = []):
        q = Queue(user, keys)
        cls.queues[user] = q
        return q

    # 删除交换机
    @classmethod
    def remove(cls, user):
        try:
            del cls.queues[user]
            return True
        except:
            return False


def inquisitor(second: int = 30):
    '''
    检察官
    定期删除过期交换机
    '''
    print('开启检察官')
    while True:
        print('检察官开始检查')
        box=[]
        # 遍历所有消息队列
        for u, q in ExchangeManage.queues.items():
            q.connection.process_data_events()
            # 若消息队列使用时间小于当前时间
            if q.time < time.time():
                # 将交换机存入盒子
                box+=[u]
        for u in box:
            print(f'{u}交换机已过期,移除交换机')
            ExchangeManage.remove(u)
        # 休息时间
        time.sleep(second)


def run(second: int):
    # 创建线程
    t = Thread(target=inquisitor, args=(second,))
    # 设置线程随主线程退出
    t.setDaemon(True)

    # 开启线程
    t.start()


run(30)
