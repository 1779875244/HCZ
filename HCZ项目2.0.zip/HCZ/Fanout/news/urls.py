from django.urls import path,include
from news import views as v

urlpatterns = [
    path('',v.news)
]
