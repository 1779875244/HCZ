import re

from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from news.exchange_control import ExchangeManage
import time


async def news(request):
    # 获取用户信息 名称-关注key
    # js_data = request.body
    # print(js_data)
    url=request.META.get('HTTP_REFERER','')
    user=request.META.get('HTTP_AUTHORIZATION','')

    print(url,user)

    if not url or not user:
        result = {'code': 10086, 'error': '服务器忙'}
        return JsonResponse(result)

    room=re.findall(r'http://127.0.0.1:5000/video/(sp\d+)/\d*', url)[0]
    # user = 'tom'
    # room = 'room1'
    # 若没有取到用户名或者聊天室
    if not bool(user) and bool(room):
        result = {'code': 10086, 'error': '请求不合法'}
        return JsonResponse(result)

    user=user+'-'+room
    print('进入到查找交换机')
    #查找对应交换机
    if user in ExchangeManage.queues:
        # 有则获取交换机
        e = ExchangeManage.queues[user]
        print('找到交换机')
    else:
        # 无则创建交换机
        e = await ExchangeManage.add(user, [room, 'system'])
        print('创建交换机')

    #整理数据返回
    try:
        print('整理数据')
        while not e.info:
            try:
                await e.run()
            except:
                ExchangeManage.remove(user)
                e = await ExchangeManage.add(user, [room, 'system'])
        else:
            # 获得消息
            data = e.info
            # 初始化容器
            e.info = None
            # 刷新交换机时间
            e.time = time.time()+300

        print('返回数据')
        result = {'code': 200, 'data': data}
        # result = {'code': 200, 'data': '测试'}
        return JsonResponse(result)


    except Exception as e:
        print('错误',e)
        result = {'code': 10086, 'error': '服务器忙'}
        return JsonResponse(result)
