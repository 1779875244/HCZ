'''

管理员消息模块
---------------------------

'''

import pika

connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='127.0.0.1'))

channel = connection.channel()

#设置交换机
channel.exchange_declare(exchange='news_info',			# 设置交换机名
                         exchange_type='direct')		# 设置发布订阅模式


if __name__ == "__main__":
    print('请输入管理员消息:')
    message='管理员--'+input('>>')


    channel.basic_publish(exchange='news_info',			# 设置使用交换机
                        routing_key='system',			# 使用交换机模式,不能设置关联键
                        body=message)

    connection.close()