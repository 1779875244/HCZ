######################################################
#        > File Name: flask_client.py
#      > Author: xiaonanguo
#     > Mail: 66666666@qq.com
#     > Created Time: Mon 20 May 2020 11:52:00 AM CST
######################################################
from flask import Flask, send_file
import sys

app = Flask(__name__)


@app.route('/index')
def index():
    # 首页
    return send_file('templates/index.html')

@app.route('/')
def index2():
    # 首页
    return send_file('templates/index.html')

@app.route('/index1/<username>')
def index1(username):
    # 首页
    return send_file('templates/index.html')


@app.route('/hang')
def hang():
    # 个人主页
    return send_file('templates/hang.html')


@app.route('/login')
def login():
    # 登录
    return send_file('templates/login.html')


@app.route('/register')
def register():
    # 注册
    return send_file('templates/register.html')


@app.route('/xgmm')
def xgmm():
    # 注册
    return send_file('templates/xgmm.html')


@app.route('/video')
def video():
    # 注册
    return send_file('templates/video.html')

@app.route('/video/<psid>/0')
def video1(psid):
    #注册
    return send_file('templates/video.html')

@app.route('/video/<psid>/<pn>')
def video2(psid,pn):
    #注册
    return send_file('templates/video.html')


@app.route('/sousuo')
def sousuo():
    # 注册
    return send_file('templates/sousuo.html')


@app.route('/xggrxx')
def xggrxx():
    # 注册
    return send_file('templates/xggrxx.html')

@app.route('/zhifu')
def zhifu():
    # 注册
    return send_file('templates/zhifu.html')

@app.route('/zhifu_result')
def zhifu_result():
    # 注册
    return send_file('templates/zhifu_result.html')

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=5000)
