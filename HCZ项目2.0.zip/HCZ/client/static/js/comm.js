$(function(){
    dnblog_user = window.localStorage.getItem('dnblog_user');
    if(dnblog_user){
        html = '';
        html += '<samp id="law"></samp>';
        html += '<a href="#" id="out" onclick="out()">退出</a>';
        $('nav div').html(html);
        $("#law").html(dnblog_user);
    }else{
        html = '';
        html += '<a href="#" id="login">登录</a>';
        html += '<a href="#" id="register">注册</a>';
        $('nav div div').html(html);
    }
})


function out(){

    if(confirm("确定登出吗？")){
                window.localStorage.removeItem('dnblog_token');
                window.localStorage.removeItem('dnblog_user');
                window.location.href= '/index';
    }
}

