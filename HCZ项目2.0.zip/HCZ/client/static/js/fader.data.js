var faderData = [
    {
        "img_url":"dj.jpg",
        "img_info":"夏日 心动信号!"
    },
    {
        "img_url":"dj1.jpg",
        "img_info":"萌宠大作战!"
    },
    {
        "img_url":"dj2.webp",
        "img_info":"硬要赢!!!!"
    }
]
